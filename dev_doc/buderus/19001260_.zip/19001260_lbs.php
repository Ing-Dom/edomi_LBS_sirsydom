###[DEF]###
[name				= Buderus EMS plus (v0.2)				]

[e#1	important	= trigger		#init=0					]
[e#2	important	= IP-address							]
[e#3	important	= Private-Key (Hex)						]

[e#29				= hc1_operationMode						]
[e#30				= hc1_temperatureRoomSetpoint			]
[e#31				= hc1_manualRoomSetpoint				]
[e#32				= hc1_temporaryRoomSetpoint				]

[e#34				= hc1_activeSwitchProgram				]

[e#35				= hc1_temperatureLevels_eco				]
[e#36				= hc1_temperatureLevels_comfort2		]

[e#40				= dhw1_operationMode					]

[e#42				= dhw1_temperatureLevels_low			]
[e#43				= dhw1_temperatureLevels_high			]

[e#46				= dhw1_charge							]

[e#47				= dhw1_chargeDuration					]
[e#48				= dhw1_singleChargeSetpoint				]

[e#50				= Loglevel #init=8						]


[a#1				= notifications							]

[a#3				= sys_healthStatus						]
[a#4				= sys_sensor_temp_outdoor_t1			]
[a#5				= sys_sensor_temp_supply_t1_setpoint	]
[a#6				= sys_sensor_temp_supply_t1				]
[a#7				= sys_sensor_temp_return				]
[a#8				= sys_sensor_temp_switch				]
[a#9				= sys_app_actualSupplyTemperature		]
[a#10				= sys_app_powerSetpoint					]
[a#11				= sys_app_actualPower					]
[a#12				= sys_app_CHpumpModulation				]
[a#13				= sys_hs1_actualModulation				]
[a#14				= sys_hs1_actualPower					]

[a#16				= hs_actualPower						]
[a#17				= hs_actualCHPower						]
[a#18				= hs_actualDHWPower						]
[a#19				= hs_actualModulation					]
[a#20				= hs_CHpumpModulation					]
[a#21				= hs_actualSupplyTemperature			]
[a#22				= hs_powerSetpoint						]
[a#23				= hs_returnTemperature					]
[a#24				= hs_supplyTemperatureSetpoint			]
[a#25				= hs_applianceSupplyTemperature			]

[a#27				= hc1_currentRoomSetpoint				]
[a#28				= hc1_actualSupplyTemperature			]
[a#29				= hc1_operationMode						]
[a#30				= hc1_temperatureRoomSetpoint			]
[a#31				= hc1_manualRoomSetpoint				]
[a#32				= hc1_temporaryRoomSetpoint				]
[a#33				= hc1_roomtemperature					]
[a#34				= hc1_activeSwitchProgram				]
[a#35				= hc1_temperatureLevels_eco				]
[a#36				= hc1_temperatureLevels_comfort2		]
[a#37				= hc1_pumpModulation					]
[a#38				= hc1_status							]

[a#40				= dhw1_operationMode					]
[a#41				= dhw1_temperatureLevels_off			]
[a#42				= dhw1_temperatureLevels_low			]
[a#43				= dhw1_temperatureLevels_high			]
[a#44				= dhw1_currentSetpoint					]
[a#45				= dhw1_actualTemp						]
[a#46				= dhw1_charge							]
[a#47				= dhw1_chargeDuration					]
[a#48				= dhw1_singleChargeSetpoint				]
[a#49				= dhw1_status							]

[v#100				= 0.2 ]
[v#101 				= 19001260 ]
[v#102 				= Buderus EMS plus ]
[v#103 				= 0 ]

###[/DEF]###

###[HELP]###
Mit diesem LBS kann man Werte einer Buderus Heizungsanlage (mit EMS plus Bus), �ber das Buderus Gateway Logamatic web (KM50/KM100(KM200), auslesen.
Dieser LBS wurde bisher allerdings lediglich mit dem KM200 an einer W�rmepumpe vom Typ WPLS .2 getestet, laut Buderus sind die Funktionen der unterschiedlichen Gateways aber identisch und nur f�r unterschiedliche Anlagen-Typen vorgesehen.
Die Eing�nge ab e#29 werden noch nicht beachtet, da der Fokus zun�chst auf das Auslesen und nicht das �ndern von Werten gerichtet war.
Je nach Anlagen-Typ liefern auch nur bestimmte Ausg�nge �berhaupt Daten.
Es gibt auch noch die M�glichkeit PV-Daten auszulesen, wenn die Anlage �ber ein entsprechendes Modul verf�gt.
Dies konnte allerdings noch nicht getestet werden.

Erarbeitet wurde diese M�glichkeit urspr�nglich von einem Benutzer aus dem SYMCON-Forum:
https://www.symcon.de/forum/threads/25211-Buderus-Logamatic-Web-KM200-Reloaded
Die dort vorhandenen Scripte wurden zu diesem LBS zusammengesetzt.
Hier im Forum gibt es ebenfalls einen Thread dazu:
https://knx-user-forum.de/forum/supportforen/eibpc/823726-buderus-km200-kommunikationsmodul-an-eibpc

Die Kommunikation mit dem Gateway erfolgt mit verschl�sseltem Payload (kein TLS), welcher �ber mcrypt mit dem Gateway-Passwort, dem Benutzer-Passwort und einem von Buderus definierten "Salt" (alles zusammen bildet dann den private key an e#3) verschl�sselt wird.
Den f�r den LBS ben�tigten private key an e#3 kann man �ber die folgende Webseite (vom Ersteller des Threads im SYMCON-Forum) generieren lassen:
https://ssl-account.com/km200.andreashahn.info/
Da mcrypt kein Bestandteil der PHP-Installation von EDOMI ist, muss dieses nachtr�glich installiert werden.
Die Funktion mycrypt ist schon etwas betagt bzw. �berholt, daher muss die Installaion aus Dritt-Repositories erfolgen, eine Migration zu OpenSSL ist leider noch nicht gelungen.
Evtl. kann ein "Kryptografie-Experte" aus dem KNX-UF etwas dazu beisteuern? :)


Ein- und Ausg�nge

E1: Trigger, um die Daten einmalig auszulesen
E2:	IP Adresse des Buderus Gateway Logamatic web (KM50/KM100/KM200)
E3: Private-Key (in Hex)
--------------------------------------------------------------------
E29..E48: noch nicht in Funktion!
--------------------------------------------------------------------

A1..A49: jeweils ausgelesener Wert


V100: Version
V101: LBS Number
V102: Log file name
V103: Log level

Changelog:
==========
v0.2: Umbau der Kommunikationsfunktion auf cURL, Custom-Log (Danke an jonofe!) und grundlegende Fehlerbehandlung hinzugef�gt
v0.1: initiale Version

###[/HELP]###


###[LBS]###
<?
function LB_LBSID($id) {
	if ($E=logic_getInputs($id)) {
		setLogicElementVar($id, 103, $E[50]['value']); //set loglevel to #VAR 103
		if ($E[1]['refresh'] == 1 && $E[1]['value'] == 1) {
			callLogicFunctionExec(LBSID, $id);
		}
	}
}
?>
###[/LBS]###


###[EXEC]###
<?
require(dirname(__FILE__)."/../../../../main/include/php/incl_lbsexec.php");
sql_connect();
set_time_limit(60);

$curl_errno = 0;

logging($id, "Buderus EMS plus LBS gestartet");

if ($E = logic_getInputs($id)) {
	
	$ipaddress = $E[2]['value'];
	$private_key_hex = $E[3]['value'];

	define( "km200_gateway_host", $ipaddress, true );
	define( "km200_crypt_key_private", hextobin($private_key_hex));

	### notifications ###
	$data = km200_GetData('/notifications');
	
	if ($curl_errno == 0) {
		if (count($data['values']) > 0)
			logic_setOutput($id,1,1);
		else 
			logic_setOutput($id,1,0);

		### system ###
		$data = km200_GetData('/system/healthStatus');
		logic_setOutput($id,3,$data['value']);

		$data = km200_GetData('/system/sensors/temperatures/outdoor_t1');
		logic_setOutput($id,4,$data['value']);

		$data = km200_GetData('/system/sensors/temperatures/supply_t1_setpoint');
		logic_setOutput($id,5,$data['value']);

		$data = km200_GetData('/system/sensors/temperatures/supply_t1');
		logic_setOutput($id,6,$data['value']);

		$data = km200_GetData('/system/sensors/temperatures/return');
		logic_setOutput($id,7,$data['value']);

		$data = km200_GetData('/system/sensors/temperatures/switch');
		logic_setOutput($id,8,$data['value']);

		$data = km200_GetData('/system/appliance/actualSupplyTemperature');
		logic_setOutput($id,9,$data['value']);

		$data = km200_GetData('/system/appliance/powerSetpoint');
		logic_setOutput($id,10,$data['value']);

		$data = km200_GetData('/system/appliance/actualPower');
		logic_setOutput($id,11,$data['value']);

		$data = km200_GetData('/system/appliance/CHpumpModulation');
		logic_setOutput($id,12,$data['value']);

		$data = km200_GetData('/system/heatSources/hs1/actualModulation');
		logic_setOutput($id,13,$data['value']);

		$data = km200_GetData('/system/heatSources/hs1/actualPower');
		logic_setOutput($id,14,$data['value']);

		### heatSources ###
		$data = km200_GetData('/heatSources/actualPower');
		logic_setOutput($id,16,$data['value']);

		$data = km200_GetData('/heatSources/actualCHPower');
		logic_setOutput($id,17,$data['value']);

		$data = km200_GetData('/heatSources/actualDHWPower');
		logic_setOutput($id,18,$data['value']);

		$data = km200_GetData('/heatSources/actualModulation');
		logic_setOutput($id,19,$data['value']);

		$data = km200_GetData('/heatSources/CHpumpModulation');
		logic_setOutput($id,20,$data['value']);

		$data = km200_GetData('/heatSources/actualSupplyTemperature');
		logic_setOutput($id,21,$data['value']);

		$data = km200_GetData('/heatSources/powerSetpoint');
		logic_setOutput($id,22,$data['value']);

		$data = km200_GetData('/heatSources/returnTemperature');
		logic_setOutput($id,23,$data['value']);

		$data = km200_GetData('/heatSources/supplyTemperatureSetpoint');
		logic_setOutput($id,24,$data['value']);

		$data = km200_GetData('/heatSources/applianceSupplyTemperature');
		logic_setOutput($id,25,$data['value']);

		### heatingCircuits ###
		$data = km200_GetData('/heatingCircuits/hc1/currentRoomSetpoint');
		logic_setOutput($id,27,$data['value']);

		$data = km200_GetData('/heatingCircuits/hc1/actualSupplyTemperature');
		logic_setOutput($id,28,$data['value']);

		$data = km200_GetData('/heatingCircuits/hc1/operationMode');
		logic_setOutput($id,29,$data['value']);

		$data = km200_GetData('/heatingCircuits/hc1/temperatureRoomSetpoint');
		logic_setOutput($id,30,$data['value']);

		$data = km200_GetData('/heatingCircuits/hc1/manualRoomSetpoint');
		logic_setOutput($id,31,$data['value']);

		$data = km200_GetData('/heatingCircuits/hc1/temporaryRoomSetpoint');
		logic_setOutput($id,32,$data['value']);

		$data = km200_GetData('/heatingCircuits/hc1/roomtemperature');
		logic_setOutput($id,33,$data['value']);

		$data = km200_GetData('/heatingCircuits/hc1/activeSwitchProgram');
		logic_setOutput($id,34,$data['value']);

		$data = km200_GetData('/heatingCircuits/hc1/temperatureLevels/eco');
		logic_setOutput($id,35,$data['value']);

		$data = km200_GetData('/heatingCircuits/hc1/temperatureLevels/comfort2');
		logic_setOutput($id,36,$data['value']);

		$data = km200_GetData('/heatingCircuits/hc1/pumpModulation');
		logic_setOutput($id,37,$data['value']);	

		$data = km200_GetData('/heatingCircuits/hc1/status');
		logic_setOutput($id,38,$data['value']);		
		
		### dhwCircuits ###
		$data = km200_GetData('/dhwCircuits/dhw1/operationMode');
		logic_setOutput($id,40,$data['value']);

		$data = km200_GetData('/dhwCircuits/dhw1/temperatureLevels/off');
		logic_setOutput($id,41,$data['value']);

		$data = km200_GetData('/dhwCircuits/dhw1/temperatureLevels/low');
		logic_setOutput($id,42,$data['value']);

		$data = km200_GetData('/dhwCircuits/dhw1/temperatureLevels/high');
		logic_setOutput($id,43,$data['value']);

		$data = km200_GetData('/dhwCircuits/dhw1/currentSetpoint');
		logic_setOutput($id,44,$data['value']);

		$data = km200_GetData('/dhwCircuits/dhw1/actualTemp');
		logic_setOutput($id,45,$data['value']);

		$data = km200_GetData('/dhwCircuits/dhw1/charge');
		logic_setOutput($id,46,$data['value']);

		$data = km200_GetData('/dhwCircuits/dhw1/chargeDuration');
		logic_setOutput($id,47,$data['value']);
		
		$data = km200_GetData('/dhwCircuits/dhw1/singleChargeSetpoint');
		logic_setOutput($id,48,$data['value']);
		
		$data = km200_GetData('/dhwCircuits/dhw1/status');
		logic_setOutput($id,49,$data['value']);
	}
}

logging($id, "Buderus EMS plus LBS beendet");
sql_disconnect();

function myErrorHandler($errno, $errstr, $errfile, $errline)
{
	global $id;
	logging($id, "File: $errfile | Error: $errno | Line: $errline | $errstr ");
}

function error_off()
{
	$error_handler = set_error_handler("myErrorHandler");
	error_reporting(0);
}

function error_on()
{
	restore_error_handler();
	error_reporting(E_ALL);
}

function logging($id,$msg, $var=NULL, $priority=8)
{
	$E=getLogicEingangDataAll($id);
	$logLevel = getLogicElementVar($id,103);
	if (is_int($priority) && $priority<=$logLevel && $priority>0)
	{
		$logLevelNames = array('none','emerg','alert','crit','err','warning','notice','info','debug');
		$version = getLogicElementVar($id,100);
		$lbsNo = getLogicElementVar($id,101);
		$logName = getLogicElementVar($id,102) . ' --- LBS'.$lbsNo;
		strpos($_SERVER['SCRIPT_NAME'],$lbsNo) ? $scriptname='EXE'.$lbsNo : $scriptname = 'LBS'.$lbsNo;
		writeToCustomLog($logName,str_pad($logLevelNames[$logLevel],7), $scriptname." [v$version]:\t".$msg);
		
		if (is_object($var)) $var = get_object_vars($var); // transfer object into array
		if (is_array($var)) // print out array
		{
			writeToCustomLog($logName,str_pad($logLevelNames[$logLevel],7), $scriptname." [v$version]:\t================ ARRAY/OBJECT START ================");
			foreach ($var as $index => $line)
				writeToCustomLog($logName,str_pad($logLevelNames[$logLevel],7), $scriptname." [v$version]:\t".$index." => ".$line);
			writeToCustomLog($logName,str_pad($logLevelNames[$logLevel],7), $scriptname." [v$version]:\t================ ARRAY/OBJECT END ================");
		}
	}
}

function km200_Decrypt( $decryptData )
{
	$decrypt = (mcrypt_decrypt( MCRYPT_RIJNDAEL_128, km200_crypt_key_private, base64_decode($decryptData), MCRYPT_MODE_ECB, '' ) );
	// remove zero padding
	$decrypt = rtrim( $decrypt, "\x00" );
	// remove PKCS #7 padding
	$decrypt_len = strlen( $decrypt );
	$decrypt_padchar = ord( $decrypt[ $decrypt_len - 1 ] );
	for ( $i = 0; $i < $decrypt_padchar ; $i++ )
	{
		if ( $decrypt_padchar != ord( $decrypt[$decrypt_len - $i - 1] ) )
		break;
	}
	if ( $i != $decrypt_padchar )
		return $decrypt;
	else
		return substr(
			$decrypt,
			0,
			$decrypt_len - $decrypt_padchar
		);
}

function km200_GetData( $REST_URL )
{
  global $id, $curl_errno;
  error_off();
  
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'http://' . km200_gateway_host . $REST_URL);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/json'));
  curl_setopt($ch, CURLOPT_USERAGENT,'TeleHeater/2.2.3');
  curl_setopt($ch, CURLOPT_HEADER, 1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  $output = curl_exec($ch);
  
  $curl_errno = curl_errno($ch);
  
  $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
  $header = substr($output, 0, $header_size);
  $body = substr($output, $header_size);
  
  if (empty($output) or $curl_errno != 0) {
	logging($id, 'Fehler: ' . curl_error($ch));
  } else {
    $info = curl_getinfo($ch);

    if ($info['http_code'] != 200) {
		if (empty($info['http_code'])) {
			logging($id, "HTTP Fehler (ohne Code) beim Aufruf der URL " . $info['url']);
		} else {
			logging($id, "HTTP Fehler-Code " . $info['http_code'] . " beim Aufruf der URL " . $info['url']);
		}
	} else {
		  return json_decode(
			km200_Decrypt(
			  $body
			),
			true //Achtung! Hier das true (und dr�ber das Komma) macht aus dem decodierten Objekt ein Array zur weiteren Bearbeitung)
		  );
	}
  }
  
  curl_close($ch);  

  error_on();
}

function km200_Encrypt( $encryptData )
{
	// add PKCS #7 padding
	$blocksize = mcrypt_get_block_size(
		MCRYPT_RIJNDAEL_128,
		MCRYPT_MODE_ECB
	);
	$encrypt_padchar = $blocksize - ( strlen( $encryptData ) % $blocksize );
	$encryptData .= str_repeat( chr( $encrypt_padchar ), $encrypt_padchar );
	// encrypt
	return base64_encode(
		mcrypt_encrypt(
			MCRYPT_RIJNDAEL_128,
			km200_crypt_key_private,
			$encryptData,
			MCRYPT_MODE_ECB,
			''
		)
	);
}

function km200_SetData( $REST_URL, $Value )
{
	$content = json_encode(
		array(
			"value" => $Value
		)
	);
	$options = array(
		'http' => array(
	   	'method' => "PUT",
	    	'header' => "Content-type: application/json\r\n" .
	                	"User-Agent: TeleHeater/2.2.3\r\n",
			'content' => km200_Encrypt( $content )
		)
	);
	$context = stream_context_create( $options );
	@file_get_contents(
		'http://' . km200_gateway_host . $REST_URL,
		false,
		$context
	);
}

function hextobin($hexstr) 
{ 
	$n = strlen($hexstr); 
	$sbin="";   
	$i=0; 
	while($i<$n) 
	{       
		$a =substr($hexstr,$i,2);           
		$c = pack("H*",$a); 
		if ($i==0){$sbin=$c;} 
		else {$sbin.=$c;} 
		$i+=2; 
	} 
	return $sbin; 
} 

?>
###[/EXEC]###